const fetch = require("node-fetch");

let UP_KEY = process.env.UP_API_KEY;

exports.handler = async (event) => {
  let transactionURL = event.data.relationships.transaction.links.related;

  const requestHeaders = {
    headers: {
      Authorization: "Bearer " + UP_KEY,
    },
  };

  const upTransaction = await fetch(transactionURL, requestHeaders)
    .then((r) => r.text())
    .then((json) => {
      try {
        return JSON.parse(json);
      } catch (err) {
        return json;
      }
    });

  let response = {
    statusCode: 200,
    body: upTransaction,
  };

  console.log(response);
  return response;
};
